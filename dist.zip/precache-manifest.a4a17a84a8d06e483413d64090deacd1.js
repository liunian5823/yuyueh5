self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7b92fc80a33372bce0fc",
    "url": "/css/app.8df38de3.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "bf447ea30032d599167293e35da172ba",
    "url": "/img/background.bf447ea3.png"
  },
  {
    "revision": "ef8eec49332cac7a1591d38fe4f912ae",
    "url": "/img/bg.ef8eec49.png"
  },
  {
    "revision": "424353e98bf814b1052c25411612a17f",
    "url": "/img/logo.424353e9.png"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/img/logo.82b9c7a5.png"
  },
  {
    "revision": "09a61ee3692e6ea0af1b3c50dcc23fc9",
    "url": "/index.html"
  },
  {
    "revision": "6995d73373174c6ae0ab",
    "url": "/js/about.acd35f30.js"
  },
  {
    "revision": "7b92fc80a33372bce0fc",
    "url": "/js/app.1b709db0.js"
  },
  {
    "revision": "0ed88aff8ed74ded850c",
    "url": "/js/chunk-vendors.bfa77f64.js"
  },
  {
    "revision": "c026e8fc0cc713ccd9056e231d8b7e51",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);